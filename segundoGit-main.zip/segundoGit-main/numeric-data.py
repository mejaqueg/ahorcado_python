print("Python tiene tres tipos númericos: int, float, y complex")

myValue=1
print(myValue)
print(type(myValue))
print (str(myValue) + " es un dato de tipo " + str(type(myValue)))

myValue=3.14
print(myValue)
print(type(myValue))
print (str(myValue) + " es un dato de tipo  " + str(type(myValue)))

myValue=5j
print(myValue)
print(type(myValue))
print (str(myValue) + " es un dato de tipo " + str(type(myValue)))

myValue=True
print(myValue)
print(type(myValue))
print (str(myValue) + " es un dato de tipo " + str(type(myValue)))

myValue=False
print(myValue)
print(type(myValue))
print (str(myValue) + " es un dato de tipo " + str(type(myValue)))
print(f"{myValue} es un dato de tipo {(type(myValue))}")
