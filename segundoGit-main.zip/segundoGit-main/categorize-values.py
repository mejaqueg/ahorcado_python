# Ejercicio 1:

myMixedTypeList = [45, 290578, 1.02, True, "Mi perro está en la cama.", 45]
for item in myMixedTypeList:
    print("{} es del tipo de dato {}".format(item,type(item)))
    