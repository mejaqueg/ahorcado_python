# Ejercicio 1

myFruitList= ["manzana", "plátano", "guinda"]
print(myFruitList)
print(type(myFruitList))

# Acceso a una lista por posición:

print(myFruitList[0])
print(myFruitList[1])
print(myFruitList[2])

myFruitList[2] = "naranja"
print(myFruitList)


# Ejercicio 2

myFinalAnswerTuple = ("manzana", "plátano", "piña")
print(myFinalAnswerTuple)
print(type(myFinalAnswerTuple))

# Acceso a una tupla por posición:

print(myFinalAnswerTuple[0])
print(myFinalAnswerTuple[1])
print(myFinalAnswerTuple[2])


# Ejercicio 3

myFavouriteFruitDictionary = {
    "Akua" : "manzana",
    "Saanvi" : "plátano",
    "Paulo" : "piña"
}
print(myFavouriteFruitDictionary)
print(type(myFavouriteFruitDictionary))

# Acceso al diccionario por nombre

print(myFavouriteFruitDictionary["Akua"])
print(myFavouriteFruitDictionary["Saanvi"])
print(myFavouriteFruitDictionary["Paulo"])